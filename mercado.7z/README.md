# Tutorial Scrapy; Extraer información de Mercado Libre

Si quieres ver como se realizo este proyecto puedes verlo en video: https://goo.gl/73crqm

Si tienes alguna duda, puedes crear una pregunta en: [Issues](https://github.com/luisramirez-m/mercadolibre-scrapy/issues "Issues")

## Modificaciones:


### [0.0.3] - 2017-09-13
- Cambios para el nuevo diseño de Mercado Libre
- Se removieron muchos campos/variables que Mercado Libre ya no usa


### [0.0.2] - 2017-03-12
- Bajar imágenes del producto
  - Recuerda cambiar en el archivo settings.py tu ruta donde quieres que se descargen las imágenes:

    ```
    IMAGES_STORE = '/URL/DE/TU/DIRECTORIO/imagenes'
    ```

### [0.0.1] - 2017-03-11
- Primera version
- Tutorial en video
